<x-app-layout>
    <x-slot name="header">
        <h2 class="font-semibold text-xl text-gray-800 leading-tight">
            {{ __('Data Anggota') }}
        </h2>
    </x-slot>

    <div class="py-12">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
            <div class="bg-white overflow-hidden shadow-sm sm:rounded-lg p-6">
                <div class="flex justify-between items-center mb-4">
                    <h1 class="text-2xl font-bold">Daftar Member</h1>
                    <a href="{{ route('members.create') }}" class="bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded shadow">
                        + Tambah Member
                    </a>
                </div>

                @if($members->isEmpty())
                    <p class="text-gray-600">Belum ada data anggota.</p>
                @else
                <table class="table-auto w-full border border-gray-200">
                    <thead class="bg-gray-300">
                        <tr>
                            <th class="px-4 py-2 border">Nama</th>
                            <th class="px-4 py-2 border">Divisi</th>
                            <th class="px-4 py-2 border">Angkatan</th>
                            <th class="px-4 py-2 border">Aksi</th>
                        </tr>
                    </thead>
                    <tbody>
                        @foreach($members as $member)
                        <tr class="hover:bg-gray-50">
                            <td class="px-4 py-2 border">{{ $member->nama }}</td>
                            <td class="px-4 py-2 border capitalize">{{ $member->divisi }}</td>
                            <td class="px-4 py-2 border">{{ $member->angkatan }}</td>
                            <td class="px-4 py-2 border">
                                <a href="{{ route('members.edit', $member->id) }}" class="bg-yellow-400 hover:bg-yellow-500 text-white px-3 py-1 rounded text-sm">Edit</a>
                                <a href="{{ route('members.show', $member->id) }}" class="bg-orange-400 hover:bg-orange-500 text-white px-3 py-1 rounded text-sm">Show</a>

                                <form action="{{ route('members.destroy', $member->id) }}" method="POST" class="inline-block ml-2" onsubmit="return confirm('Yakin ingin menghapus member ini?')">
                                    @csrf
                                    @method('DELETE')
                                    <button type="submit" class="bg-red-500 hover:bg-red-600 text-white px-3 py-1 rounded text-sm">
                                        Hapus
                                    </button>
                                </form>
                            </td>
                        </tr>
                        @endforeach
                    </tbody>
                </table>
                @endif
            </div>
        </div>
    </div>
</x-app-layout>
