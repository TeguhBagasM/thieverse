<div class="space-y-4">
    <!-- Nama -->
    <div>
        <label for="nama" class="block text-sm font-medium text-gray-700">Nama</label>
        <input type="text" name="nama" id="nama" class="w-full border-gray-300 rounded-md shadow-sm focus:ring-indigo-500 focus:border-indigo-500 px-3 py-2" value="{{ old('nama', $member->nama ?? '') }}" required>
    </div>

    <!-- Divisi -->
    <div>
        <label for="divisi" class="block text-sm font-medium text-gray-700">Divisi</label>
        <select name="divisi" id="divisi" class="w-full border-gray-300 rounded-md shadow-sm focus:ring-indigo-500 focus:border-indigo-500 px-3 py-2">
            <option value="pemrograman" {{ old('divisi', $member->divisi ?? '') == 'pemrograman' ? 'selected' : '' }}>Pemrograman</option>
            <option value="multimedia" {{ old('divisi', $member->divisi ?? '') == 'multimedia' ? 'selected' : '' }}>Multimedia</option>
        </select>
    </div>

    <!-- Alamat -->
    <div>
        <label for="alamat" class="block text-sm font-medium text-gray-700">Alamat</label>
        <textarea name="alamat" id="alamat" class="w-full border-gray-300 rounded-md shadow-sm focus:ring-indigo-500 focus:border-indigo-500 px-3 py-2" required>{{ old('alamat', $member->alamat ?? '') }}</textarea>
    </div>

    <!-- Angkatan -->
    <div>
        <label for="angkatan" class="block text-sm font-medium text-gray-700">Angkatan</label>
        <input type="number" name="angkatan" id="angkatan" class="w-full border-gray-300 rounded-md shadow-sm focus:ring-indigo-500 focus:border-indigo-500 px-3 py-2" value="{{ old('angkatan', $member->angkatan ?? '') }}" required>
    </div>

    <!-- IPK -->
    <div>
        <label for="ipk" class="block text-sm font-medium text-gray-700">IPK</label>
        <input type="number" step="0.01" name="ipk" id="ipk" class="w-full border-gray-300 rounded-md shadow-sm focus:ring-indigo-500 focus:border-indigo-500 px-3 py-2" value="{{ old('ipk', $member->ipk ?? '') }}" required>
    </div>

    <!-- Status -->
    <div>
        <label for="status" class="block text-sm font-medium text-gray-700">Status</label>
        <select name="status" id="status" class="w-full border-gray-300 rounded-md shadow-sm focus:ring-indigo-500 focus:border-indigo-500 px-3 py-2">
            <option value="1" {{ old('status', $member->status ?? '') == '1' ? 'selected' : '' }}>Aktif</option>
            <option value="0" {{ old('status', $member->status ?? '') == '0' ? 'selected' : '' }}>Nonaktif</option>
        </select>
    </div>
</div>
