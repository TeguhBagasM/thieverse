<x-app-layout>
    <x-slot name="header">
        <h2 class="font-semibold text-xl text-gray-800 leading-tight">
            {{ __('Detail Member') }}
        </h2>
    </x-slot>

    <div class="py-12">
        <div class="max-w-3xl mx-auto sm:px-6 lg:px-8">
            <div class="bg-white overflow-hidden shadow-sm sm:rounded-lg p-6">
                <h1 class="text-2xl font-bold mb-4">Detail Member</h1>

                <div class="space-y-4">
                    <div>
                        <strong>Nama:</strong> {{ $member->nama }}
                    </div>
                    <div>
                        <strong>Divisi:</strong> {{ ucfirst($member->divisi) }}
                    </div>
                    <div>
                        <strong>Alamat:</strong> {{ $member->alamat }}
                    </div>
                    <div>
                        <strong>Angkatan:</strong> {{ $member->angkatan }}
                    </div>
                    <div>
                        <strong>IPK:</strong> {{ $member->ipk }}
                    </div>
                    <div>
                        <strong>Status:</strong> {{ $member->status ? 'Aktif' : 'Nonaktif' }}
                    </div>
                    <div class="mt-6">
                        <a href="{{ route('members.index') }}" class="bg-gray-500 text-white px-4 py-2 rounded">Kembali</a>
                        <a href="{{ route('members.edit', $member->id) }}" class="bg-yellow-500 text-white px-4 py-2 rounded ml-2">Edit</a>
                        <form action="{{ route('members.destroy', $member->id) }}" method="POST" class="inline-block ml-2">
                            @csrf
                            @method('DELETE')
                            <button type="submit" class="bg-red-500 text-white px-4 py-2 rounded">Hapus</button>
                        </form>
                    </div>
                </div>

            </div>
        </div>
    </div>
</x-app-layout>
